<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Semkanisa Kopsis Dashboard')); ?></title>
        <!-- Favicon -->
        <link class="img-rounded" href="<?php echo e(asset('img/brand/SemkanisaKopsis-Logo-01.png')); ?>" rel="icon" type="image/png">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
        <!-- Extra details for Live View on GitHub Pages -->

        <!-- Icons -->
        <link href="<?php echo e(asset('argon/vendor/nucleo/css/nucleo.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('argon/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
        <!-- Argon CSS -->
        <link type="text/css" href="<?php echo e(asset('argon/css/argon.css?v=1.0.0')); ?>" rel="stylesheet">
        <!-- preloader -->
        <link rel="stylesheet" href="<?php echo e(asset('css/preloader.css')); ?>">
    </head>
    <body id="stop-scrolling" class="<?php echo e($class ?? ''); ?>">
        <div class="preloader">
            <div class="loading" id="loading">
                <img class="prelogo" src="<?php echo e(asset('img/brand/orange.png')); ?>" alt="">
                <br>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
              </div>
        </div>
        <?php if(auth()->guard()->check()): ?>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            <?php echo $__env->make('layouts.navbars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <div class="main-content" id="panel">
            <?php echo $__env->make('layouts.navbars.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php if(auth()->guard()->guest()): ?>
            <?php echo $__env->make('layouts.footers.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        
        <!-- JQuery -->
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

        <?php echo $__env->yieldPushContent('js'); ?>

        <!-- Argon JS -->
        <script src="<?php echo e(asset('argon/js/argon.js?v=1.0.0')); ?>"></script>
        <!-- Preloader -->
        <script>
            function preloaderFadeOutInit(){
                $('.preloader').fadeOut(1000);
                $('body').attr('id','stop-scrolling');
                }
                // Window load function
                jQuery(window).on('load', function () {
                (function ($) {
                preloaderFadeOutInit();
                })(jQuery);
            });
        </script>
        <script src="<?php echo e(asset('js/pagechange.js')); ?>"></script>

        <script>
            document.body.style.overflow-y = 'hidden';
        </script>
    </body>
</html>
<?php /**PATH D:\Putra\SMK\PKK\Produk 2\SemkanisaKopsisAPI\resources\views/layouts/app.blade.php ENDPATH**/ ?>